package com.kalvin.J12306.api;

/**
 * 检查用户状态
 * Create by Kalvin on 2019/9/19.
 */
public class CheckUser {
}
