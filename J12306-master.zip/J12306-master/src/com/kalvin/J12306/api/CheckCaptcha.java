package com.kalvin.J12306.api;

/**
 * 校验验证码
 * Create by Kalvin on 2019/9/19.
 */
public class CheckCaptcha {
}
